import React from 'react'

const ProductDetail = () => {
  return (
    <div>상품상세페이지</div>
  )
}

export default ProductDetail